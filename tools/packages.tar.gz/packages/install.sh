if [[ $# -ne 1 ]];
then
  echo "sh install.sh HOME_PATH"
  exit 1
fi
WORK_HOME=$1
tar -zxf ncurses-6.2.tar.gz
tar -xJf zsh-5.8.tar.xz
tar -zxf vimrc.tar.gz
tar -zxf oh-my-zsh.tar.gz
mv .vim .vimrc .zshrc .oh-my-zsh $WORK_HOME

export CXXFLAGS=" -fPIC"
export CFLAGS=" -fPIC"
INSTALL_PATH="${WORK_HOME}/.install"

cd ncurses-6.2
./configure --prefix=$INSTALL_PATH --enable-shared
make -j 
make install

export PATH=$INSTALL_PATH/bin:$PATH
export LD_LIBRARY_PATH=$INSTALL_PATH/lib:$LD_LIBRARY_PATH
export CFLAGS=-I$INSTALL_PATH/include
export CPPFLAGS="-I$INSTALL_PATH/include"
export LDFLAGS="-L$INSTALL_PATH/lib"

cd ../zsh-5.8
./configure --prefix=$INSTALL_PATH --enable-shared
make -j 
make install
